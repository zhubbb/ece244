#include <string>

int main(int argc,char **argv)
{
	if (argc != 1)
	{
		cerr << "Needs one argument (a string)" << endl;
		return -1;
	}
	string str(argv[1]);

	count << "Length of string is " << str.		// this line needs completion
	return 0;
}
