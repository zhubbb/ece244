void try_place (struct s_placer_opts placer_opts, struct s_annealing_sched 
            annealing_sched, t_chan_width_dist chan_width_dist);

void read_place (char *place_file, char *net_file, char *arch_file,
            struct s_placer_opts placer_opts, t_chan_width_dist 
            chan_width_dist);
