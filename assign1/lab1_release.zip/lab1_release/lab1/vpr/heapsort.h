void heapsort_vpr (int *sort_index, float *sort_values, int nelem);
