vpr e64-4lut.net 4lut_sanitized.arch placed.out routed.out -nodisp
